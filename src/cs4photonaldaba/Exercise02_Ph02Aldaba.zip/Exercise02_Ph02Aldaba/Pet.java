public class Pet
{
    String petName;
    String petSpecies;
    int petAge;
    int perfsAttended;

    public Pet(String petName, String petSpecies, int petAge, int perfsAttended)
    {
        this.petName = petName;
        this.petSpecies = petSpecies;
        this.petAge = petAge;
        this.perfsAttended = perfsAttended;
    }

    public void attendPerf(int perfsAttended)
    {
        this.perfsAttended = perfsAttended;
    }
    
}
