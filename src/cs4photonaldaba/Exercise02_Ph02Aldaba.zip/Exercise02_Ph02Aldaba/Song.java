public class Song
{
    String title;
    String artist;
    int releaseYear;

    public Song(String title, String artist, int releaseYear)
    {
        this.title = title;
        this.artist = artist;
        this.releaseYear = releaseYear;
    }
}
