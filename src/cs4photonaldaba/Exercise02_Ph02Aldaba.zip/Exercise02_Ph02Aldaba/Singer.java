public class Singer 
{
    String name;
    int noOfPerf;
    double earnings;
    Song favSong = new Song("", "", 0);

    public Singer(String name, Song favSong, int noOfPerf, double earnings)
    {
        this.name = name;
        this.favSong = favSong;
        this.noOfPerf = noOfPerf;
        this.earnings = earnings;
    }

    public void performForAudience(int earnings)
    {
        noOfPerf++;

        this.earnings += earnings * 100;
    }

    public void changeFavSong(Song newSong)
    {
        favSong = newSong;
    }

}



