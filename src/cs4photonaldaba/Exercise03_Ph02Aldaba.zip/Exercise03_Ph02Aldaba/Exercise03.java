public class Exercise03 
{
    public static void main(String[] args)
    {
        Pet pet1 = new Pet("Tochi", "Cat", 4, 0);
        Pet pet2 = new Pet("Doggie", "Dog", 6, 0);
        Pet pet3 = new Pet("Brooklyn", "Dog", 6, 0);

        Song song1 = new Song("Falling Behind", "Laufey", 2022);
        Song song2 = new Song("Fragile", "Laufey", 2022);
        Singer singer1 = new Singer("Laufey", null, 0, 0);

        singer1.changeFavSong(song1);
        singer1.performForAudience(12);
        singer1.changeFavSong(song2);

    }
}
