public class Pet
{
    private String petName;
    private String petSpecies;
    private int petAge;
    private int perfsAttended;
    private static int noOfPets;

    public Pet(String petName, String petSpecies, int petAge, int perfsAttended)
    {
        this.petName = petName;
        this.petSpecies = petSpecies;
        this.petAge = petAge;
        this.perfsAttended = perfsAttended;
        noOfPets++;
    }

    public void attendPerf(int perfsAttended)
    {
        this.perfsAttended = perfsAttended;
    }

    public static int getNoOfPets() {
        return noOfPets;
    }

    //____________getters and setters____________//

    public String getPetName() {
        return this.petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public String getPetSpecies() {
        return this.petSpecies;
    }

    public void setPetSpecies(String petSpecies) {
        this.petSpecies = petSpecies;
    }

    public int getPetAge() {
        return this.petAge;
    }

    public void setPetAge(int petAge) {
        this.petAge = petAge;
    }

    public int getPerfsAttended() {
        return this.perfsAttended;
    }

    public void setPerfsAttended(int perfsAttended) {
        this.perfsAttended = perfsAttended;
    }

    public void setNoOfPets(int noOfPets) {
        this.noOfPets = noOfPets;
    } 

}
