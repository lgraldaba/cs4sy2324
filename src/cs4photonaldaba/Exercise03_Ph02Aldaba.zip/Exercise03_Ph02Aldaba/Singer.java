public class Singer 
{
    private String name;
    private int noOfPerf;
    private double earnings;
    private Song favSong = new Song("", "", 0);
    private static int noOfSingers;

    public Singer(String name, Song favSong, int noOfPerf, double earnings)
    {
        this.name = name;
        this.favSong = favSong;
        this.noOfPerf = noOfPerf;
        this.earnings = earnings;
        noOfSingers++;
    }

    public void performForAudience(int people)
    {
        this.noOfPerf++;
        this.earnings += people * 100;
    }

    public void performForAudience(Singer collab, int people)
    {
        this.noOfPerf++;
        this.earnings += people * 50;

        collab.noOfPerf++;
        collab.earnings += people * 50;
    }

    public void changeFavSong(Song newSong)
    {
        favSong = newSong;
    }

    public static int getNoOfPets() {
        return noOfSingers;
    }

    //____________getters and setters____________//


    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNoOfPerf() {
        return this.noOfPerf;
    }

    public void setNoOfPerf(int noOfPerf) {
        this.noOfPerf = noOfPerf;
    }

    public double getEarnings() {
        return this.earnings;
    }

    public void setEarnings(double earnings) {
        this.earnings = earnings;
    }

    public Song getFavSong() {
        return this.favSong;
    }

    public void setFavSong(Song favSong) {
        this.favSong = favSong;
    }

}



