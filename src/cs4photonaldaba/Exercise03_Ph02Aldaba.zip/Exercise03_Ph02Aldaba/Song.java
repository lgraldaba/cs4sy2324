public class Song
{
    private String title;
    private String artist;
    private int releaseYear;
    private static int noOfSongs;

    public Song(String title, String artist, int releaseYear)
    {
        this.title = title;
        this.artist = artist;
        this.releaseYear = releaseYear;
    }

    public static int getNoOfPets() {
        return noOfSongs;
    }

    //____________getters and setters____________//

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getArtist() {
        return this.artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public int getReleaseYear() {
        return this.releaseYear;
    }

    public void setReleaseYear(int releaseYear) {
        this.releaseYear = releaseYear;
    }

}
