import java.util.Scanner;
 
public class Exercise_04{
	public static void main(String[] args){
		Move rock = new Move("Rock");
		Move paper = new Move("Paper");
		Move scissors = new Move("Scissors");
		
		Scanner scan = new Scanner(System.in);
		
		rock.setStrongAgainst(scissors);
		paper.setStrongAgainst(rock);
		scissors.setStrongAgainst(paper);
		
		boolean gameRunning = true;
		int chooseOption;
		int intMoveChoice;
		int outcome;
		int currentRound = 0;
		int roundsToWin = 2;
		int computerScore = 0;
		int playerScore = 0;
		Move moveChoice = null;
		Move computerMoveChoice = null;
		

		//means it will always run unless gameRunning is set to false
		while(gameRunning == true)
		{
			System.out.println("");
			System.out.println("Welcome to Rock, Paper, Scissors. Please choose an option");
			System.out.println("1: Start game");
			System.out.println("2: Change number of rounds");
			System.out.println("3: Exit application");
			chooseOption = Integer.parseInt(scan.nextLine());
			System.out.println("");

			switch(chooseOption)
			{
				//starts the game
				case 1:

					System.out.printf("This game will be first to %s \n\n", roundsToWin);
					while(computerScore != roundsToWin && playerScore != roundsToWin)
					{	
						currentRound += 1;
						System.out.printf("\nRound #%s \n", currentRound);
						System.out.println("1: Rock");
						System.out.println("2: Paper");
						System.out.println("3: Scissors");
						intMoveChoice = Integer.parseInt(scan.nextLine());

						//translates integer value into Move
						switch(intMoveChoice)
						{
							case 1:
								moveChoice = rock;
								break;

							case 2:
								moveChoice = paper;
								break;

							case 3:
								moveChoice = scissors;
								break;
						}

						int randomNum = (int) Math.floor(Math.random()*3) + 1;

						//computer move
						switch(randomNum)
						{
							case 1:
								computerMoveChoice = rock;
								break;

							case 2:
								computerMoveChoice = paper;
								break;

							case 3:
								computerMoveChoice = scissors;
								break;							
						}

						outcome = Move.compareMoves(moveChoice, computerMoveChoice);

						switch(outcome)
						{
							case 0:
								System.out.println("\nPlayer wins!\nScore:");
								playerScore += 1;
								System.out.printf("Player: %s Computer: %s\n", playerScore, computerScore);
								break;

							case 1:
								System.out.println("\nComputer wins!\nScore:");
								computerScore += 1;
								System.out.printf("Player: %s Computer: %s\n", playerScore, computerScore);
								break;

							case 2:
								System.out.println("\nDraw \n");
								break;
						}
					} 

					System.out.println("\nGame Finished");
					gameRunning = false;

				break;


				//insert new no. of rounds
				case 2:

					System.out.println("Insert new number of rounds here: ");
					roundsToWin = Integer.parseInt(scan.nextLine());
					System.out.println("");

				break;


				//closes game
				case 3:

					gameRunning = false;

				break;
			}
		}
	}
}